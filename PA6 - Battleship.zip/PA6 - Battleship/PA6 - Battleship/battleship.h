/*
	Programmer: Liana Wu
	Class: Cpts 121, Lab 3
	Programming Assignment: PA6
	Date: 11/8/2019

	Description: Basic Game of Battleship, a two player Navy game.
				 The objective of the game is to sink all ships in your enemy's fleet.
				 The Player to sink his/her enemy's fleet first wins.
				 Both players' fleets consist of 5 ships that are hidden from the enemy.
				 Each ship may be differentiated by its "size" (besides the Cruiser and Submarine) or number of cells it expands on the game board.
				 The Carrier has 5 cells, Battleship has 4 cells, Cruiser has 3 cells, Submarine has 3 cells, and the Destroyer has 2 cells.
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>

// User Options
#define RANDOM	1
#define MANUAL	2

// Constants
#define HUMAN_PLAYER	0
#define COMPUTER_PLAYER	1
#define HORIZONTAL		0
#define VERTICAL		1
#define ROW_NUM			10
#define COL_NUM			10
#define ITERATION_NUM	2
#define WATER			'-'

// Length of Ships 
#define SHIPS_NUM	5
#define CARRIER		5
#define BATTLESHIP	4
#define SUBMARINE	3
#define CRUISER		3
#define DESTROYER	2

// Datatype initialization
typedef struct stats {
	int total_hits, total_misses, total_shots, won_or_lost;
	double hit_miss_ratio;
} Stats;

// Function prototypes

/*
	Function: welcome_screen()
	Date Created: 11/8/2019
	Description: Displays an initial program welcome message along with the rules of Battleship.
	Input Parameters: N/A
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Displays welcome screen
*/

void welcome_screen(void);

/*
	Function: initialize_game_board()
	Date Created: 11/8/2019
	Description: Sets each cell in a game board to '-' (water).
	Input Parameters: Game board
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Initialize all game board cells to water ('-')
*/

void initialize_game_board(char board[ROW_NUM][COL_NUM]);

/*
	Function: display_board()
	Date Created: 11/8/2019
	Description: Displays a board to the screen.
	Input Parameters: Game board
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Displays the game board
*/

void display_board(char board[ROW_NUM][COL_NUM]);

/*
	Function: select_who_starts_first()
	Date Created: 11/8/2019
	Description: Determines if Player 1 or Player 2 goes first in the game.
	Input Parameters: N/A
	Returns: Random number between 0 & 1
	Preconditions: Start of program
	Postconditions: Selects who starts first
*/

int select_who_starts_first(void);

/*
	Function: generate_direction()
	Date Created: 11/8/2019
	Description: Randomly determines to place the ship horizontally or vertically
	Input Parameters: N/A
	Returns: Random number between 0 & 1
	Preconditions: Start of program
	Postconditions: Direction of ship placement
*/

int generate_direction(void);

/*
	Function: generate_random_ships()
	Date Created: 11/8/2019
	Description: Generate a random starting point for the ship
				 based on ship length and direction.
	Input Parameters: direction, ship legnth, *row, *col
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Random starting point for ship
*/

void generate_random_ships(int direction, int ship_length, int* row, int* col);

/*
	Function: random_ship_placements()
	Date Created: 11/8/2019
	Description: Places ths ships onto the game board
	Input Parameters: Game board, ship type, ship length, direction,
					  starting row position pointer,
					  starting column position pointer
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Places the ship onto the board based on type, length,
					direction, and starting position
*/

void random_ship_placements(char board[ROW_NUM][COL_NUM],  char ship_types, int ship_length, int direction, int rowStart, int colStart);

/*
	Function: manual_ship_placements()
	Date Created: 11/8/2019
	Description: Allows the user to place each of the 5 types of
				 ships on his/her game board.
	Input Parameters: Game board
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Places the ship onto the board based on user
					inputted coordiantes
*/

void manual_ship_placements(char board[ROW_NUM][COL_NUM]);

/*
	Function: check_ship_collisions()
	Date Created: 11/8/2019
	Description: Checks if the ship position is valid
				 (placed with something other than water)
	Input Parameters: Game board, direction, ship legnth,
					  starting row position, starting column position
	Returns: valid (true/false)
	Preconditions: Start of program
	Postconditions: Determines if position is valid for ship placement or not
*/

int check_ship_collisions(char board[ROW_NUM][COL_NUM], int direction, int ship_length, int row, int col);

/*
	Function: check_ship_placements()
	Date Created: 11/8/2019
	Description: Checks if all row and column are equal
	Input Parameters: Game board, coodrinates array, ship length
	Returns: Valid (true/false)
	Preconditions: Start of program
	Postconditions: Determines if game board is valid or not
*/

int check_ship_placements(char board[ROW_NUM][COL_NUM], int coords[], int ship_length);

/*
	Function: bubble_sort()
	Date Created: 11/8/2019
	Description: Sorts array elements into ascending order
	Input Parameters: Array, size of array
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Organized array
*/

void bubble_sort(int arr[], int size);

/*
	Function: check_shot()
	Date Created: 11/8/2019
	Description: Determines if the shot taken was a hit or a miss.
	Input Parameters: Game board, x position, y position,
					  ship type pointer
	Returns: Hit/Miss
	Preconditions: Start of program
	Postconditions: If the ship hit or missed the ship
*/

int check_shot(char board[ROW_NUM][COL_NUM], int xPos, int yPos, char* ship_type);

/*
	Function: check_if_sunk_ship()
	Date Created: 11/8/2019
	Description: Determines if a ship was sunk.
	Input Parameters: Game board, ship length
	Returns: Sunk (true/false)
	Preconditions: Start of program
	Postconditions: If ship has sunk or not
*/

int check_if_sunk_ship(char board[ROW_NUM][COL_NUM], char ship_type);

/*
	Function: update_board()
	Date Created: 11/8/2019
	Description: Updates the board every time a shot is taken.
				 '*' indicates a hit and 'M' indicates a miss.
	Input Parameters: Game board, x position, y position, hit
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Updates board
*/

void update_board(char board[ROW_NUM][COL_NUM], int x_pos, int y_pos, int hit);

/*
	Function: output_current_move()
	Date Created: 11/8/2019
	Description: Writes the position of the shot taken by the current player to the log file.
				 It also writes whether or not it was a hit, miss, and if the ship was sunk.
	Input Parameters: Outfile, current player, x position, y position, hit, sunk
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Records game into log
*/

void output_current_move(FILE* outfile, int currentPlayer, int x_pos, int y_pos, int hit, int sunk);

/*
	Function: winner()
	Date Created: 11/8/2019
	Description: Determines if a winner exists.
	Input Parameters: Game board
	Returns: Winner (true/false)
	Preconditions: Start of program
	Postconditions: If winner exists
*/

int winner(char board[ROW_NUM][COL_NUM]);

/*
	Function: output_stats()
	Date Created: 11/8/2019
	Description: Writes the statistics collected on each player to the log file.
	Input Parameters: Outfile, player 1 (stats), player 2 (stats)
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Displays game log
*/

void output_stats(FILE* outfile, Stats p1, Stats p2);
