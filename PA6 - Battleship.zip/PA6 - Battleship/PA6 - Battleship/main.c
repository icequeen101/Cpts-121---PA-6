/*
	Programmer: Liana Wu
	Class: Cpts 121, Lab 3
	Programming Assignment: PA6
	Date: 11/8/2019

	Description: Basic Game of Battleship, a two player Navy game.
				 The objective of the game is to sink all ships in your enemy's fleet.
				 The Player to sink his/her enemy's fleet first wins.
				 Both players' fleets consist of 5 ships that are hidden from the enemy.
				 Each ship may be differentiated by its "size" (besides the Cruiser and Submarine) or number of cells it expands on the game board.
				 The Carrier has 5 cells, Battleship has 4 cells, Cruiser has 3 cells, Submarine has 3 cells, and the Destroyer has 2 cells.
*/

#include "battleship.h"

int main(void) {

	// Initalize "random" seeds
	srand((unsigned int)time(NULL));

	// Variables 
	char p1_board[ROW_NUM][COL_NUM] = { {'\0'} },
		 p2_board[ROW_NUM][COL_NUM] = { { '\0'} },	// p2_board - debugging purposes.
		 p2_display_board[ROW_NUM][COL_NUM] = { { '\0' } },
		 ship_types[SHIPS_NUM] = { 'C', 'B', 'S', 'R', 'D' };
	int computers_move[ROW_NUM][COL_NUM] = { { 0 } };
	int ship_lengths[SHIPS_NUM] = { CARRIER, BATTLESHIP, SUBMARINE, CRUISER, DESTROYER };
	int direction = HORIZONTAL, row_start = 0, col_start = 0;
	int player_menu_input = 0, x_pos = 0, y_pos = 0, hit = false, sunk = false, generating = true;
	int placed = false, won = false, lost = false;
	char ship_hit = '\0';
	Stats p1 = { 0, 0, 0, 0.0 };
	Stats p2= { 0, 0, 0, 0.0 };
	FILE* outfile = NULL;
	outfile = fopen("battleship.log", "w");

	initialize_game_board(p1_board);
	initialize_game_board(p2_board);
	initialize_game_board(p2_display_board);

	// Game Screen 
	welcome_screen();

	// Game Begin 
	do {
		scanf("%d", &player_menu_input);
	} while (!(player_menu_input == RANDOM || player_menu_input == MANUAL));
	if (player_menu_input == RANDOM) {
		for (int i = 0; i < SHIPS_NUM; i++) {
			// Random Placement Of ships For Player (Player 1)
			placed = true;
			direction = generate_direction();
			do {
				generate_random_ships(direction, ship_lengths[i], &row_start, &col_start);
				if (check_ship_collisions(p1_board, direction, ship_lengths[i], row_start, col_start) == true) {
					random_ship_placements(p1_board, ship_types[i],ship_lengths[i],  direction, row_start, col_start);
					placed = false;
				}
			} while (placed);
		}
	}
	else {
		manual_ship_placements(p1_board);
	}

	printf("YOUR BOARD:\n");
	display_board(p1_board);
	system("pause");

	for (int i = 0; i < SHIPS_NUM; i++) {
		// Random Placement Of Ships For Computer (Player 2)
		placed = true;
		direction = generate_direction();
		do {
			generate_random_ships(direction, ship_lengths[i], &row_start, &col_start);
			if (check_ship_collisions(p2_board, direction, ship_lengths[i], row_start, col_start) == true) {
				random_ship_placements(p2_board, ship_types[i], ship_lengths[i], direction, row_start, col_start);
				placed = false;
			}
		} while (placed);
	}

	int current_player = select_who_starts_first();
	
	// Initialize Computer Parallel Array
	for (int i = 0; i < ROW_NUM; i++) {
		for (int j = 0; j < COL_NUM; j++) {
			computers_move[i][j] = 0;
		}
	}

	while (!won || !lost) {
		switch (current_player) {
		case HUMAN_PLAYER:										// Human Player
			printf("Your Board:\n");
			display_board(p1_board);
			printf("\nComputer's Board:\n");
			display_board(p2_display_board);
			printf("Enter a target: ");
			scanf("%d %d", &x_pos, &y_pos);
			p1.total_shots++;
			hit = check_shot(p2_board, x_pos, y_pos, &ship_hit);
			sunk = check_if_sunk_ship(p2_board, ship_hit);
			update_board(p2_board, x_pos, y_pos, hit);
			update_board(p2_display_board, x_pos, y_pos, hit);
			if (hit) {
				p1.total_hits++;
				printf("Hit!\n");
				if (sunk) {
					printf("You sunk the computer's ship with token %c!\n", ship_hit);
				}
			}
			else {
				p1.total_misses++;
				printf("Already Targeted/Miss...\n");
			}
			system("pause");
			system("cls");
			output_current_move(outfile, current_player, x_pos, y_pos, hit, sunk);
			if (winner(p2_board)) {
				printf("Yay! You won!\n");
				system("pause");
				won = true;
				goto breakout;
			}
			current_player = COMPUTER_PLAYER;
			break;
		case COMPUTER_PLAYER:									// Computer
			generating = true;
			while (generating) {
				x_pos = rand() % 10;
				y_pos = rand() % 10;
				if (computers_move[x_pos][y_pos] != true) {
					computers_move[x_pos][y_pos] = true;
					generating = false;
				}
			}
			p2.total_shots++;
			hit = check_shot(p1_board, x_pos, y_pos, &ship_hit);
			sunk = check_if_sunk_ship(p1_board, ship_hit);
			if (hit) {
				p2.total_hits++;
				printf("Computer selects %d, %d. It was a hit!\n", x_pos, y_pos);
				if (sunk) {
					printf("Computer selects %d, %d. It was a hit and sunk your ship!\n", x_pos, y_pos);
				}
			}
			else {
				p2.total_misses++;
				printf("Computer selects %d, %d. It was a miss.\n", x_pos, y_pos);
			}
			system("pause");
			system("cls");
			update_board(p1_board, x_pos, y_pos, hit);
			if (winner(p1_board)) {
				printf("Sorry, you lost!\n");
				system("pause");
				lost = true;
				goto breakout;
			}
			output_current_move(outfile, current_player, x_pos, y_pos, hit, sunk);
			current_player = HUMAN_PLAYER;
			break;
		}
	}

breakout:
	printf("Recording statistics to battleship log...\n");
	p1.hit_miss_ratio = ((double)p1.total_hits / p1.total_shots) * 100;
	p2.hit_miss_ratio = ((double)p2.total_hits / p2.total_shots) * 100;
	output_stats(outfile, p1, p2);
	fclose(outfile);

	return 0; 
}