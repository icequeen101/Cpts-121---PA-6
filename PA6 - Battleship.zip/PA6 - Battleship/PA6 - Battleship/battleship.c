/*
	Programmer: Liana Wu
	Class: Cpts 121, Lab 3
	Programming Assignment: PA6
	Date: 11/8/2019

	Description: Basic Game of Battleship, a two player Navy game. 
				 The objective of the game is to sink all ships in your enemy's fleet. 
				 The Player to sink his/her enemy's fleet first wins. 
				 Both players' fleets consist of 5 ships that are hidden from the enemy. 
				 Each ship may be differentiated by its "size" (besides the Cruiser and Submarine) or number of cells it expands on the game board. 
				 The Carrier has 5 cells, Battleship has 4 cells, Cruiser has 3 cells, Submarine has 3 cells, and the Destroyer has 2 cells.
*/

#include "battleship.h"

/*
	Function: welcome_screen()
	Date Created: 11/8/2019
	Description: Displays an initial program welcome message along with the rules of Battleship.
	Input Parameters: N/A
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Displays welcome screen
*/

void welcome_screen() {

	// Cool Game Title

	printf(" ____       _______ _______ _      ______  _____ _    _ _____ _____			\n");
	printf("|  _ \\   /\\|__   __|__   __| |    |  ____|/ ____| |  | |_   _|  __ \\		\n");
	printf("| |_) | /  \\  | |     | |  | |    | |__  | (___ | |__| | | | | |__) |		\n");
	printf("|  _ < / /\\ \\ | |     | |  | |    |  __|  \\___ \\|  __  | | | |  ___/	\n");
	printf("| |_) / ____ \\| |     | |  | |____| |____ ____) | |  | |_| |_| |			\n");
	printf("|____/_/    \\_\\_|     |_|  |______|______|_____/|_|  |_|_____|_|			\n\n");

	// Rules
	printf("1. This is a multiplayer, two player game.\n");
	printf("2. Player 1 is you, Player 2 is the computer.\n");
	printf("3. You and your opponent have five ships each: a carrier (length of 5 cells), battleship (4 cells), submarine (3 cells),\n");
	printf("   cruiser (3 cells), and destroyer (2 cells). Your objective is to guess your enemy's ships' coordinates.\n");
	printf("   If you manage to 'sink' (destroy all of your enemy's ships), you win!\n\n");
	printf("Press enter to start!\n");
	system("pause >nul");
	system("cls");

	// Manual or Random Ship Placement
	printf("Would you like to manually place your ships, or randomly generate a board?\n");
	printf("1. Randomly generate board.\n");
	printf("2. Manually place ships.\n");
}

/*
	Function: initialize_game_board()
	Date Created: 11/8/2019
	Description: Sets each cell in a game board to '-' (water).
	Input Parameters: Game board
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Initialize all game board cells to water ('-')
*/

void initialize_game_board(char board[ROW_NUM][COL_NUM]) {
	for (int i = 0; i < ROW_NUM; i++) {
		for (int j = 0; j < COL_NUM; j++) {
			board[i][j] = WATER;
		}
	}
}

/*
	Function: display_board()
	Date Created: 11/8/2019
	Description: Displays a board to the screen.
	Input Parameters: Game board
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Displays the game board
*/

void display_board(char board[ROW_NUM][COL_NUM]) {
	for (int i = 0; i < ROW_NUM; i++) {
		if (i == 0) {
			printf("    0  1  2  3  4  5  6  7  8  9\n");
		}
		for (int j = 0; j < COL_NUM; j++) {
			if (j == 0) {
				printf(" %d ", i);
			}
			printf(" %c ", board[i][j]);
		}
		printf("\n");
	}
}

/*
	Function: select_who_starts_first()
	Date Created: 11/8/2019
	Description: Determines if Player 1 or Player 2 goes first in the game.
	Input Parameters: N/A
	Returns: Random number between 0 & 1
	Preconditions: Start of program
	Postconditions: Selects who starts first
*/

int select_who_starts_first() {
	int player_num = rand() % 2;
	if (player_num == HUMAN_PLAYER) { //Player
		printf("Player 1 has been randomly selected to go first.\n");
	}
	else if (player_num == COMPUTER_PLAYER) { //Computer
		printf("Player 2 (computer) has been randomly selected to go first.\n");
	}
	system("pause");
	system("cls");

	return player_num;
}

/*
	Function: generate_direction()
	Date Created: 11/8/2019
	Description: Randomly determines to place the ship horizontally or vertically 
	Input Parameters: N/A
	Returns: Random number between 0 & 1
	Preconditions: Start of program
	Postconditions: Direction of ship placement 
*/

int generate_direction() {
	return rand() % 2;
}

/*
	Function: generate_random_ships()
	Date Created: 11/8/2019
	Description: Generate a random starting point for the ship 
				 based on ship length and direction. 
	Input Parameters: direction, ship legnth, *row, *col
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Random starting point for ship
*/

void generate_random_ships(int direction, int ship_length, int* row, int* col) {
	if (direction == HORIZONTAL) {
		*row = rand() % ROW_NUM;
		*col = rand() % (COL_NUM - ship_length + 1);
	}
	else if (direction == VERTICAL) {
		*col = rand() % COL_NUM;
		*row = rand() % (ROW_NUM - ship_length + 1);
	}
}

/*
	Function: random_ship_placements()
	Date Created: 11/8/2019
	Description: Places ths ships onto the game board
	Input Parameters: Game board, ship type, ship length, direction,
					  starting row position pointer, 
					  starting column position pointer
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Places the ship onto the board based on type, length,
					direction, and starting position 
*/

void random_ship_placements(char board[ROW_NUM][COL_NUM], char ship_type, int ship_length, int direction, int row_start, int col_start) {
	if (direction == HORIZONTAL) {
		for (int i = 0; i < ship_length; i++) {
			board[row_start][col_start + i] = ship_type;
		}
	}
	else if (direction == VERTICAL) {
		for (int i = 0; i < ship_length; i++) {
			board[row_start + i][col_start] = ship_type;
		}
	}
}

/*
	Function: manual_ship_placements()
	Date Created: 11/8/2019
	Description: Allows the user to place each of the 5 types of 
				 ships on his/her game board.
	Input Parameters: Game board
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Places the ship onto the board based on user 
					inputted coordiantes
*/

void manual_ship_placements(char board[ROW_NUM][COL_NUM]) {

	// Variables 
	int row = 0, col = 0;
	int carrier_pos[CARRIER * ITERATION_NUM] = { 0 }, battleship_pos[BATTLESHIP * ITERATION_NUM] = { 0 },
		submarine_pos[SUBMARINE * ITERATION_NUM] = { 0 }, cruiser_pos[CRUISER * ITERATION_NUM] = { 0 },
		destroyer_pos[DESTROYER * ITERATION_NUM] = { 0 };

carrier:
	printf("Please enter the coordinates for the carrier:\n");
	int count = 0;
	for (int i = 0; i < (CARRIER * ITERATION_NUM); i += 2) {
		printf("Row #%d: ", ++count);
		scanf("%d", &row);
		printf("Col #%d: ", count);
		scanf("%d", &col);

		if ((row >= 0 && row <= 9) && (col >= 0 && col <= 9)) {
			carrier_pos[i] = row;
			carrier_pos[i + 1] = col;
		}
		else {
			printf("Invalid Row/Column Values!\n");
			goto carrier;
		}
	}
	if (check_ship_placements(board, carrier_pos, CARRIER) == false) {
		printf("Invalid Placement. Please Try Again.\n");
		goto carrier;
	}

	// Carrier Placement
	for (int i = 0; i < (CARRIER * ITERATION_NUM); i += 2) {
		board[carrier_pos[i]][carrier_pos[i + 1]] = 'C';
	}
	display_board(board);

battleship:
	count = 0;
	printf("Please enter the coordinates for the battleship in:\n");
	for (int i = 0; i < (BATTLESHIP * ITERATION_NUM); i += 2) {
		printf("Row #%d: ", ++count);
		scanf("%d", &row);
		printf("Col #%d: ", count);
		scanf("%d", &col);
		if ((row >= 0 && row <= 9) && (col >= 0 && col <= 9)) {
			battleship_pos[i] = row;
			battleship_pos[i + 1] = col;
		}
		else {
			printf("Invalid Row/Column Values!\n");
			goto battleship;
		}
	}
	if (check_ship_placements(board, battleship_pos, BATTLESHIP) == false) {
		printf("Invalid Placement. Please Try Again.\n");
		goto battleship;
	}
	// Battleship Placement
	for (int i = 0; i < (BATTLESHIP * ITERATION_NUM); i += 2) {
		board[battleship_pos[i]][battleship_pos[i + 1]] = 'B';
	}
	display_board(board);

submarine:
	count = 0;
	printf("Please enter the coordinates for the submarine in:\n");
	for (int i = 0; i < SUBMARINE * ITERATION_NUM; i += 2) {
		printf("Row #%d: ", ++count);
		scanf("%d", &row);
		printf("Col #%d: ", count);
		scanf("%d", &col);
		if ((row >= 0 && row <= 9) && (col >= 0 && col <= 9)) {
			submarine_pos[i] = row;
			submarine_pos[i + 1] = col;
		}
		else {
			printf("Invalid Row/Column Values!\n");
			goto submarine;
		}
	}
	if (check_ship_placements(board, submarine_pos, SUBMARINE) == false) {
		printf("Invalid Placement. Please Try Again.\n");
		goto submarine;
	}
	// Submarine Placement
	for (int i = 0; i < (SUBMARINE * ITERATION_NUM); i += 2) {
		board[submarine_pos[i]][submarine_pos[i + 1]] = 'S';
	}
	display_board(board);

cruiser:
	count = 0;
	printf("Please enter the coordinates for the cruiser in:\n");
	for (int i = 0; i < CRUISER * ITERATION_NUM; i += 2) {
		printf("Row #%d: ", ++count);
		scanf("%d", &row);
		printf("Col #%d: ", count);
		scanf("%d", &col);
		if ((row >= 0 && row <= 9) && (col >= 0 && col <= 9)) {
			cruiser_pos[i] = row;
			cruiser_pos[i + 1] = col;
		}
		else {
			printf("Invalid Row/Column Values!\n");
			goto cruiser;
		}
	}
	if (check_ship_placements(board, cruiser_pos, CRUISER) == false) {
		printf("Invalid Placement. Please Try Again.\n");
		goto cruiser;
	}
	// Cruiser Placement
	for (int i = 0; i < (CRUISER * ITERATION_NUM); i += 2) {
		board[cruiser_pos[i]][cruiser_pos[i + 1]] = 'R';
	}
	display_board(board);

destroyer:
	count = 0;
	printf("Please enter the coordinates for the destroyer in:\n");
	for (int i = 0; i < DESTROYER * ITERATION_NUM; i += 2) {
		printf("Row #%d: ", ++count);
		scanf("%d", &row);
		printf("Col #%d: ", count);
		scanf("%d", &col);
		if ((row >= 0 && row <= 9) && (col >= 0 && col <= 9)) {
			destroyer_pos[i] = row;
			destroyer_pos[i + 1] = col;
		}
		else {
			printf("Invalid Row/Column Values!\n");
			goto destroyer;
		}
	}
	if (check_ship_placements(board, destroyer_pos, DESTROYER) == false) {
		printf("Invalid Placement. Please Try Again.\n");
		goto destroyer;
	}
	// Destroyer Placement
	for (int i = 0; i < (DESTROYER * 2); i += 2) {
		board[destroyer_pos[i]][destroyer_pos[i + 1]] = 'D';
	}
	system("cls");
}

/*
	Function: check_ship_collisions()
	Date Created: 11/8/2019
	Description: Checks if the ship position is valid 
				 (placed with something other than water)
	Input Parameters: Game board, direction, ship legnth, 
					  starting row position, starting column position 
	Returns: valid (true/false)
	Preconditions: Start of program
	Postconditions: Determines if position is valid for ship placement or not 
*/

int check_ship_collisions(char board[ROW_NUM][COL_NUM], int direction, int ship_length, int row, int col) {

	int valid = true;

	for (int i = 0; valid && i < ship_length; i++) {
		if (direction == HORIZONTAL) {
			if (board[row][col + i] != WATER &&
				(col + i) < COL_NUM)
				valid = false;
		}
		else { /* VERTICAL */
			if (board[row + i][col] != WATER &&
				(row + i) < ROW_NUM)
				valid = false;
		}
	}

	return valid;
}

/*
	Function: check_ship_placements()
	Date Created: 11/8/2019
	Description: Checks if all row and column are equal
	Input Parameters: Game board, coodrinates array, ship length 
	Returns: Valid (true/false)
	Preconditions: Start of program
	Postconditions: Determines if game board is valid or not 
*/

int check_ship_placements(char board[ROW_NUM][COL_NUM], int coords[], int ship_length) {
	int row_valid = true, col_valid = true, count = 0;
	int row_check = coords[0];
	int col_check = coords[1];
	int row_pos[100] = { 0 };
	int col_pos[100] = { 0 };

	//Row checking
	for (int i = 0; i < ship_length * ITERATION_NUM; i += 2) {
		row_pos[count] = coords[i];
		if (coords[i] != row_check) {
			row_valid = false;
		}
		count++;
	}

	//Column checking
	count = 0;
	for (int i = 1; i < ship_length * ITERATION_NUM; i += 2) {
		col_pos[count] = coords[i];
		if (coords[i] != col_check) {
			col_valid = false;
		}
		count++;
	}

	if ((row_valid && !col_valid)) {
		//Check column values are in sequence by sorting
		bubble_sort(col_pos, ship_length);
		for (int i = 1; i < ship_length; i++) {
			if ((col_pos[i] > col_pos[i - 1] + 1) || board[row_pos[i]][col_pos[i]] != WATER) {
				return false;
			}
		}
		return true;
	}
	else if ((!row_valid && col_valid)) {
		//Check row values are in sequence by sorting
		bubble_sort(row_pos, ship_length);
		for (int i = 1; i < ship_length; i++) {
			if ((row_pos[i] > row_pos[i - 1] + 1) || board[row_pos[i]][col_pos[i]] != WATER) {
				return false;
			}
		}
		return true;
	}
	return false;
}

/*
	Function: bubble_sort()
	Date Created: 11/8/2019
	Description: Sorts array elements into ascending order
	Input Parameters: Array, size of array
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Organized array
*/

void bubble_sort(int arr[], int size) {
	int temp = 0;
	for (int i = 0; i < size; i++) {
		for (int j = 0; j < size - i - 1; j++) {
			if (arr[j] > arr[j + 1]) {
				temp = arr[j];
				arr[j] = arr[j + 1];
				arr[j + 1] = temp;
			}
		}
	}
}

/*
	Function: check_shot()
	Date Created: 11/8/2019
	Description: Determines if the shot taken was a hit or a miss.
	Input Parameters: Game board, x position, y position, 
					  ship type pointer
	Returns: Hit/Miss 
	Preconditions: Start of program
	Postconditions: If the ship hit or missed the ship
*/

int check_shot(char board[ROW_NUM][COL_NUM], int x_pos, int y_pos, char* ship_type) {
	for (int i = 0; i < ROW_NUM; i++) {
		for (int j = 0; j < COL_NUM; j++) {
			if (i == x_pos && j == y_pos) {

 				if (board[i][j] != WATER && board[i][j] != 'M' && board[i][j] != '*') {
						*ship_type = board[i][j];
					return true;
				}
			}
		}
	}
	return false;
}

/*
	Function: check_if_sunk_ship()
	Date Created: 11/8/2019
	Description: Determines if a ship was sunk.
	Input Parameters: Game board, ship length 
	Returns: Sunk (true/false)
	Preconditions: Start of program
	Postconditions: If ship has sunk or not
*/

int check_if_sunk_ship(char board[ROW_NUM][COL_NUM], char ship_type) {
	int count = 0;
	for (int i = 0; i < ROW_NUM; i++) {
		for (int j = 0; j < COL_NUM; j++) {
			if (board[i][j] == ship_type) {
				count++;
			}
		}
	}

	// Checks if ship has at least one cell (Function executes nefore board updates)
	if (count == 1) {
		return true;
	}
	return false;
}

/*
	Function: update_board()
	Date Created: 11/8/2019
	Description: Updates the board every time a shot is taken. 
				 '*' indicates a hit and 'M' indicates a miss.
	Input Parameters: Game board, x position, y position, hit
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Updates board 
*/

void update_board(char board[ROW_NUM][COL_NUM], int x_pos, int y_pos, int hit) {
	char ship_type = '\0';
	for (int i = 0; i < ROW_NUM; i++) {
		for (int j = 0; j < COL_NUM; j++) {
			if (i == x_pos && j == y_pos) {
				if (hit) {
					board[i][j] = '*';
				}
				else {
					board[i][j] = 'M';
				}
			}
		}
	}
}

/*
	Function: output_current_move()
	Date Created: 11/8/2019
	Description: Writes the position of the shot taken by the current player to the log file. 
				 It also writes whether or not it was a hit, miss, and if the ship was sunk.
	Input Parameters: Outfile, current player, x position, y position, hit, sunk 
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Records game into log 
*/

void output_current_move(FILE* outfile, int current_player, int x_pos, int y_pos, int hit, int sunk) {
	switch (current_player) {
	case HUMAN_PLAYER: // Human Player
		if (hit) {
			if (sunk) {
				fprintf(outfile, "Player 1 attacked at %d, %d. It was a hit, and the enemy's ship sank!\n", x_pos, y_pos);
			}
			else {
				fprintf(outfile, "Player 1 attacked at %d, %d. It was a hit!\n", x_pos, y_pos);
			}
		}
		else {
			fprintf(outfile, "Player 1 attacked at %d, %d. It was a miss.\n", x_pos, y_pos);
		}
		break;
	case 1: // Computer
		if (hit) {
			if (sunk) {
				fprintf(outfile, "Computer attacked at %d, %d. It was a hit, and the player's ship sank!\n", x_pos, y_pos);
			}
			else {
				fprintf(outfile, "Computer attacked at %d, %d. It was a hit!\n", x_pos, y_pos);
			}
		}
		else {
			fprintf(outfile, "Computer attacked at %d, %d. It was a miss.\n", x_pos, y_pos);
		}
		break;
	}
}

/*
	Function: winner()
	Date Created: 11/8/2019
	Description: Determines if a winner exists.
	Input Parameters: Game board
	Returns: Winner (true/false)
	Preconditions: Start of program
	Postconditions: If winner exists
*/

int winner(char board[ROW_NUM][COL_NUM]) {
	int hit_count = 0;
	for (int i = 0; i < ROW_NUM; i++) {
		for (int j = 0; j < COL_NUM; j++) {
			if (board[i][j] == '*') {
				hit_count++;
			}
		}
	}
	if (hit_count == 17) {
		return true;
	}
	return false;
}

/*
	Function: output_stats()
	Date Created: 11/8/2019
	Description: Writes the statistics collected on each player to the log file.
	Input Parameters: Outfile, player 1 (stats), player 2 (stats)
	Returns: N/A
	Preconditions: Start of program
	Postconditions: Displays game log 
*/

void output_stats(FILE* outfile, Stats playerOne, Stats playerTwo) {
	fprintf(outfile, "Player One Stats:\n");
	fprintf(outfile, "-----------------\n");
	fprintf(outfile, "Number of Hits: %d\n", playerOne.total_hits);
	fprintf(outfile, "Number of Misses: %d\n", playerOne.total_misses);
	fprintf(outfile, "Total Number of Shots: %d\n", playerOne.total_shots);
	fprintf(outfile, "Hit/Miss Ratio: %.2lf%%\n", playerOne.hit_miss_ratio);
	fprintf(outfile, "\n");
	fprintf(outfile, "Computer Stats:\n");
	fprintf(outfile, "-----------------\n");
	fprintf(outfile, "Number of Hits: %d\n", playerTwo.total_hits);
	fprintf(outfile, "Number of Misses: %d\n", playerTwo.total_misses);
	fprintf(outfile, "Total Number of Shots: %d\n", playerTwo.total_shots);
	fprintf(outfile, "Hit/Miss Ratio: %.2lf%%\n", playerTwo.hit_miss_ratio);
}
